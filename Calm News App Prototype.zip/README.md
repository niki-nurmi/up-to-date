
  # Calm News App Prototype

  This is a code bundle for Calm News App Prototype. The original project is available at https://www.figma.com/design/U7GUaWddhsvbos064hQR7P/Calm-News-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  